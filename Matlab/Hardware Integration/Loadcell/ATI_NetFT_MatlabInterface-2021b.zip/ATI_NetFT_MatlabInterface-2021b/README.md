# ATI_NetFT_MatlabInterface
Basic code to sample the the ATI Net-FT sensors from within MATLAB

# Setup
* TCP/IPv4 settings on your machine: static IP 192.168.1.100, submask 255:255:255:0

# ATI user Manual
User manual: http://www.ati-ia.com/app_content/documents/9610-05-1022%20Quick%20Start.pdf


